import java.time.LocalDate;
public class CheckingAccount extends Account {
	private int overdraftLimit = -100;
	
	CheckingAccount(){
		
	}
	
	CheckingAccount(int id, double balance, double annualInterestRate,
			double monthlyInterestRate, double deposit){
		setId(id);
		setBalance(balance);
		setAnnualInterestRate(annualInterestRate);
		setDateCreated(LocalDate.now());
		setMonthlyInterestRate(monthlyInterestRate);
		deposit(deposit);
	}
	@Override
	double deposit(double deposit) {
		double balance = getBalance() + deposit;
		if(balance <= overdraftLimit) {
			System.out.println("withdrawl balance exceeded");
			return getBalance();
		}
		else {
			setBalance(balance);
			return balance;
		}
}
	@Override
	double withdrawl(double amount) {
		double balance = getBalance() - amount;
		if(balance <= overdraftLimit) {
			System.out.println("withdrawl balance exceeded");
			return getBalance();
		}
		else {
			setBalance(balance);
			return balance;
		}
	}
}

		


