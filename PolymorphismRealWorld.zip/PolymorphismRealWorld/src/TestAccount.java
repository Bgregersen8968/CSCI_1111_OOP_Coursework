import java.text.DecimalFormat;

class TestAccount {
	public static void main(String[] args) {
		
		Account mySavings = new SavingsAccount();
		DecimalFormat df = new DecimalFormat("########.##");
		mySavings.setId(1111);
		mySavings.setBalance(20000);
		mySavings.setAnnualInterestRate(4.5);
		mySavings.setMonthlyInterestRate(4.5);
		mySavings.withdrawl(20000);
		mySavings.deposit(5);
		double SavingsBalance = mySavings.getBalance();
		double SavingsannualInterestRate = mySavings.getAnnualInterestRate();
		double SavingsMonthlyInterestRate = mySavings.getMonthlyInterestRate();
		double SavingsMonthlyInterest = mySavings.getMonthlyInterest(SavingsBalance, SavingsMonthlyInterestRate);
		System.out.println("Date Created : " + mySavings.getDateCreated());
		System.out.println("I.D. number : " + mySavings.getId());
		System.out.println("Current balance : " + "$" + df.format(SavingsBalance) + ("\n"));
		//System.out.println("Monthly interest : " + "$ " + Math.round(SavingsMonthlyInterest * 100) / 100 + ".00");
		
		CheckingAccount myChecking = new CheckingAccount();
		myChecking.setId(2222);
		myChecking.setBalance(1000);
		myChecking.setAnnualInterestRate(4.5);
		myChecking.setMonthlyInterestRate(4.5);
		myChecking.withdrawl(3000);
		myChecking.deposit(30);
		double checkingBalance = myChecking.getBalance();
		double CheckingAnnualInterestRate = myChecking.getAnnualInterestRate();
		double CheckingMonthlyInterestRate = myChecking.getMonthlyInterestRate();
		double CheckingMonthlyInterest = myChecking.getMonthlyInterest(checkingBalance, CheckingMonthlyInterestRate);
		System.out.println("Date Created : " + myChecking.getDateCreated());
		System.out.println("I.D. number : " + myChecking.getId());
		System.out.println("Current balance : " + ("$ ") + df.format(checkingBalance)+ ("\n"));
		//System.out.println("Monthly interest : " + "$ " + Math.round(SavingsMonthlyInterest * 100) / 100 + ".00");
	}
}

