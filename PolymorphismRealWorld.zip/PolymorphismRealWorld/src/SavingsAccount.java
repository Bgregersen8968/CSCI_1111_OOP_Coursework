import java.time.LocalDate;

public class SavingsAccount extends Account {
	public int minimumBalance = 0;
	SavingsAccount(){
		
	}
	
	SavingsAccount(int id, double balance, double annualInterestRate,
			double monthlyInterestRate, double deposit){
		setId(id);
		setBalance(balance);
		setAnnualInterestRate(annualInterestRate);
		setDateCreated(LocalDate.now());
		setMonthlyInterestRate(monthlyInterestRate);
		deposit(deposit);
	}
	@Override
	double deposit(double deposit) {
		double balance = getBalance() + deposit;
		if(balance <= minimumBalance) {
			System.out.println("withdrawl balance exceeded");
			return getBalance();
		}
		else {
			setBalance(balance);
			return balance;
		}
}
	@Override
	double withdrawl(double amount) {
		double balance = getBalance() - amount;
		if(balance <= minimumBalance) {
			System.out.println("withdrawl balance exceeded");
			return getBalance();
		}
		else {
			setBalance(balance);
			return balance;
		}
	}
}

		

